
Cell_a$Arrival_Time = Cell_a$Arrival_Time / 1000000

Cell_a$Arrival_Time


min_value = min(Cell_a$Arrival_Time)
max_value = max(Cell_a$Arrival_Time)
Cell_a$Arrival_Time = Cell_a$Arrival_Time - minimo
Cell_a$Arrival_Time



mean_arrival_notNormal = mean(Cell_a$Arrival_Time)
Cell_a$standardized_time <- (Cell_a$Arrival_Time - mean_arrival_notNormal) / sd(Cell_a$Arrival_Time)


mean_arrival = round(mean(Cell_a$standardized_time))


hist(Cell_a$standardized_time, freq = F)

curve(dpois(x,lambda = mean_arrival), 
      lwd = 3,
      col = "red",
      add = T)

